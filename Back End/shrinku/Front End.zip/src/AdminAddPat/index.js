import React from 'react';
import Home from '../HomeWrapper';
import AddPatient from '../AddPatient';
const AdminAddPat = () => {
    return ( <Home>
<div style={{padding:"50px"}}>

        <AddPatient />
</div>
    </Home> );
}

export default AdminAddPat;