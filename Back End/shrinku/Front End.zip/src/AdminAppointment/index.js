import React from 'react';
import Home from '../HomeWrapper';
import CreateAppointment from '../CreateAppointment';

const AdminAppointment = () => {
    return ( <Home>
        <br/>
        <CreateAppointment />

    </Home> );
}

export default AdminAppointment;