import React from 'react';
import Home from '../HomeWrapper';
import AddDoctor from '../AddDoctor';
const AdminAddDoc = () => {
    return ( <Home>
<div style={{padding:"50px"}}>

        <AddDoctor />
</div>
    </Home> );
}

export default AdminAddDoc;